#define ultrasonicTrigger 7
#define ultrasonicEcho 6

#define mcu2Address 9

#define lcdPinOne 13
#define lcdPinTwo 12
#define lcdPinThree 11
#define lcdPinFour 10
#define lcdPinFive 9
#define lcdPinSix 8

#define ledPin 2
