#define address 9

#define lcdPinOne 13
#define lcdPinTwo 12
#define lcdPinThree 11
#define lcdPinFour 10
#define lcdPinFive 9
#define lcdPinSix 8
