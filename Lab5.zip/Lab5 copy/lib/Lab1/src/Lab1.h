#ifndef LAB1_H
#define LAB1_H

#include "mystdio.h"
#include "ledd.h"

class Lab1 {
    public:
        Lab1(void);
        void setup(void);
        void loop(void);
}

#endif